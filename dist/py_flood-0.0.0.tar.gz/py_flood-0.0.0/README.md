### Usage

#### CLI

To use threads:

    python3 main.py <ip_address> <first_port> <last_port> <n_threads>

One theads with verbose output

    python3 flood.py <ip_address> <first_port> <last_port>
